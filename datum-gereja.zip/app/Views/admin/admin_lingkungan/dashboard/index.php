<?= $this->extend('admin/layout/template'); ?>
<?= $this->section('content'); ?>

<?= $this->endSection(); ?>